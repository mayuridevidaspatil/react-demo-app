const jwt = require("jsonwebtoken")

/**
 * JwtVerify verfiy token & return decoded data
 * ex : { email: 'user@example.com', iat: 1697293493, exp: 1697293613 }
 * 
 * note : You can use callback instead of promise
 */
const JwtVerify= async (token)=>{
    try{
        const decoded = await jwt.verify(token, process.env.JWTSECRETKEY)
        return decoded
    }catch(err){
        return err
    }
}

/**
 * JwtSignIn create a new token using email payload
 */
const JwtSignIn=(email)=>{
    const token = jwt.sign({ email }, process.env.JWTSECRETKEY, {
        expiresIn: "60s",
        algorithm: "HS256"
    })
    return token
}

module.exports = {JwtVerify, JwtSignIn}