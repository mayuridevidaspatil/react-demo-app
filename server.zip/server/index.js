const express = require("express")
const cors = require("cors")
const mongoose = require("mongoose")
const userRouter = require("./routes/user")
const refreshToken = require("./routes/refreshToken")
const verifyToken = require("./middleware/verfiyToken")
const app = express()
const PORT = 4001
require("dotenv").config()


mongoose.connect(process.env.MONGODB)
.then(res=>{
    console.log('Connected')
})
.catch(err=>{
    console.log('Connection failed')
})

app.use(express.json())
app.use(cors())

app.use('/user',userRouter)

app.post('/check', verifyToken, (req, res)=>{  // Added VerifyToken Middleware if user have valid token it let user to next
    console.log(req["user"],req["token"])
    res.send("Token is verified")
})

app.use('/auth',verifyToken, refreshToken)

app.listen(PORT, console.log(`Server port is running on port ${PORT}`))