const { JwtVerify } = require("../services/auth")

const verifyToken = async (request,response,next)=>{
    try{
        const token = request.headers["authorization"]
        if (!token) { // if there is no token in header authorization
            return response.status(401).send("Unauthorized..")
        }
        
        const decoded = await JwtVerify(token) // Verifing token
        
        if (!decoded?.email){
            return response.status(401).send("Unauthorized..") // if email is exist in decoded payload
        } 
    
        request["user"] = decoded // attach decoded data in request
        request["token"] = token // attach Token in request
        next()
    }catch{
        return response.status(401).send("Unauthorized..")
    }
}

module.exports = verifyToken