const express = require("express")
const User = require('../models/user')
const jwt = require("jsonwebtoken")
const { JwtSignIn } = require("../services/auth")
const router = express.Router()


router.post('/signup', async (req, res) => {
    const { firstName, LastName, email, password, role, gender } = req.body
    await User.create({
        firstName,
        LastName,
        email,
        password,
        role,
        gender
    })

    return res.status(201).send("Created Successfully")
})

router.post('/signin', async (req, res) => {
    const { email, password } = req.body
    try {
        const userCred = await User.findOne({ email, password })
        if (!userCred) {
            return res.status(400).send("Invalid Credential")
        }

        const token = JwtSignIn(email)
        return res.status(201).send(token)
    } catch (error) {
        res.status(409).send('conflict')
    }

    return res.status(201).send("login")
})

module.exports = router