const express = require("express")
const router = express.Router()
const jwt = require("jsonwebtoken")
const User = require("../models/user")
const { JwtSignIn, JwtVerify } = require("../services/auth")

router.post('/refreshToken', async (req, res) => {

    try {
        const {email} = req["user"]    
    
        const userCred = await User.findOne({ email })
        
        if (!userCred) res.status(401).send("Unauthorized..")

        const refreshToken = JwtSignIn(email)

        return res.status(201).send(refreshToken)
   
    } catch (err) {
        console.log('conflict',err)
    }
})


module.exports = router