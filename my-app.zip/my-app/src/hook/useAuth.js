import { useEffect, createContext, useState } from "react";
import { reGenerateToken } from "../api/apiIntegration";
import { useAuthCtx } from "../context/auth";
import { useNavigate } from "react-router-dom";

function useAuth() {
    const navigate = useNavigate()
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [token, setToken] = useState(localStorage.getItem("token"))
    const {tokenCtx, setTokenCtx} = useAuthCtx()
    
    function refreshToken(getToken){
        if(getToken){
            console.log("get token", getToken)
         reGenerateToken(getToken)
        .then(refreshtoken=>{
            localStorage.setItem("token",refreshtoken)
            setTokenCtx(refreshtoken)
        })
        .catch(err=>{
            localStorage.removeItem("token")
            setTokenCtx(null)
            navigate("/signin")
        })
        .finally(()=>{
            setIsRefreshing(false)
        })
        }       
    }

    useEffect(() => {
        let intervalId;
        let timeUntilExpiration;
        let token = localStorage.getItem("token");
        if(token){
            let tempToken = JSON.parse(atob(localStorage.getItem("token")?.split(".")[1]))
            let now = Date.now() / 1000;
            timeUntilExpiration = tempToken.exp - Math.floor(now);      
        }   
        
        const checkTokenExpiration = () => { // These method is running every 20 sec
            if(!isRefreshing){
                const getToken = localStorage.getItem("token")
                setIsRefreshing(true);
                refreshToken(getToken)
            }     
        }

        // These method will run if in case any component re-render while interval of 20sec it handle
        // and send call refresh token
        if(timeUntilExpiration < 20){  
            if(!isRefreshing){
             console.log("if time less than 20 sec",timeUntilExpiration)
             const getToken = localStorage.getItem("token")
             refreshToken(getToken)
            }
        }
        console.log(Math.abs(timeUntilExpiration-5*10000))
        intervalId = setInterval(checkTokenExpiration, Math.abs(timeUntilExpiration-5*10000));
        return () => {
            clearInterval(intervalId);
        };

        }, [tokenCtx])

        return token
}

export default useAuth;