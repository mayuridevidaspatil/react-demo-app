import React,{useEffect} from 'react'

const useCountDown = (tokenCtx,setTime) => {
    function checkToken() {
        if (tokenCtx !== null) {
            const tempToken = JSON.parse(atob(tokenCtx?.split(".")[1]))
            let now = Date.now() / 1000;
            setTime(tempToken.exp - Math.floor(now)) // every time we getting updated seconds
        }
    }

    useEffect(() => {
        let intervalId;
        intervalId = setInterval(checkToken, 1000);
        return () => {
            clearInterval(intervalId);
        };
    }, [tokenCtx])
}

export default useCountDown
