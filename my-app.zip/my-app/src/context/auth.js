import { createContext, useContext, useState } from "react"

const initialState = {
    token : null
}

const authContext = createContext(initialState)

export const useAuthCtx = () =>{
   return useContext(authContext)
} 


export const AuthProvider=({children})=>{
    const [tokenCtx, setTokenCtx] = useState(null)
    return(
        <authContext.Provider value={{tokenCtx, setTokenCtx}}>
            {children}
        </authContext.Provider>
    )
}