import axios from "axios";

let config = {
    headers: {
        "Content-Type": "application/json",
    },
};

export const signupApi = async (user) => {
    return axios.post("http://localhost:4001/user/signup", user, config)
        .then((res) => {
            if (res.status == 201) {
                return res;
            }
        });
}


export const signinApi = async (user) => {
    return axios.post("http://localhost:4001/user/signin", user, config)
        .then((res) => {
            if (res.status == 201) {
                return res;
            }
        });
}


export const reGenerateToken = async (token) => {
    console.log("API Inside reGenerateToken::");
    
    return axios.post("http://localhost:4001/auth/refreshtoken",{},{
        headers : {
           authorization : token
        }
    })
        .then((res) => {
            if (res.status == 201) {
                return res.data;
            }
        })
}