import React, { useEffect, useState } from "react";
import { Route, Routes, useNavigate } from "react-router-dom";
import "./App.css";
//import Signup from "./components/Signup"; 
//import Dashboard from "./components/Dashboard"; 
//import Product from "./components/Product"; 
//import Service from "./components/Service"; 
//import Customer from "./components/Customer"; 
//import PageNotFound from "./components/pageNotFound"; 
import Header from "./components/Header";
import useAuth from "./hook/useAuth";
import SignIn from "./components/SignIn";
import Parent from "./components/Parent";
import Protected from "./components/Protected";
import Dashboard from "./components/Dashboard";
import Service from "./components/Service";
import Product from "./components/Product";
import { useAuthCtx } from "./context/auth";
import Customer from "./components/Customer";

function App() {

  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [token, setToken] = useState(null)
  const { tokenCtx, setTokenCtx } = useAuthCtx()

  useEffect(() => {
    console.log("Inside useeffect App");
    const token = localStorage.getItem("token");
    if (token) {
      setTokenCtx(token)
    }
    // if (!token) {
    //   setIsLoggedIn(false);
    // } else {
    //   setToken(token)
    //   setIsLoggedIn(true);
    // }
  }, [tokenCtx])

  const logout = () => {
    setIsLoggedIn(false);
    setTokenCtx(null)
    localStorage.removeItem("token");
    navigate("/signin");
  };

  return (
    <>
      {tokenCtx ? <Header logout={logout}></Header> : null}

      <Routes>
        <Route path="/" element={<SignIn setIsLoggedIn={setIsLoggedIn} />} />
        <Route path="/signin" element={<SignIn setIsLoggedIn={setIsLoggedIn} />} />

        <Route path="/dashboard" element={
          <Protected>
            <Parent>
              <Dashboard />
            </Parent>
          </Protected>
        }
        />

        <Route path="/service" element={
          <Protected>
            <Parent>
              <Service />
            </Parent>
          </Protected>
        }
        />

        <Route path="/product" element={
          <Protected>
            <Parent>
              <Product />
            </Parent>
          </Protected>
        }
        />

       <Route path="/customer" element={
          <Protected>
            <Parent>
              <Customer />
            </Parent>
          </Protected>
        }
           />
      </Routes>
    </>
  )
}

export default App;