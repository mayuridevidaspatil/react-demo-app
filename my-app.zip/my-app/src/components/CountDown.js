import React,{useEffect, useState} from 'react'
import { useAuthCtx } from "../context/auth";
import useCountDown from '../hook/useCountDown';

const CountDown = () => {
    const { tokenCtx, _ } = useAuthCtx()
    const [time, setTime] = useState(0)
   
    useCountDown(tokenCtx, setTime)

    return (
        <div>
           0:0:{time}
        </div>
    )
}

export default CountDown
