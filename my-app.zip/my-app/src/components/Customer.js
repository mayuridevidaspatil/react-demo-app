import React, { useEffect, useState } from 'react'
import { Navigate,Na } from "react-router-dom"

const Customer = () => {
  const [loading, setLoading ] = useState(true)
  useEffect(()=>{
    setTimeout(()=>{
     setLoading(false)
    },5000)

  },[loading])

  return (    
    <>
    {console.log('render')}
      {loading ? <div>loading....</div> : <div>Data is loaded</div> }
    </>
  )
}

export default Customer