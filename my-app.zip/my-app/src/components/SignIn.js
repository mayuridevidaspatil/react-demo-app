import React,{useEffect} from 'react'
import {Container} from "@mui/material"
import Box from "@mui/material/Box"
import Avatar from '@material-ui/core/Avatar'
import {LockOutlined} from "@mui/icons-material"
import {
  Button,
  Grid,
  TextField,
  ThemeProvider,
  createTheme,
  Typography
} from "@material-ui/core"
import { signinApi } from "../api/apiIntegration"
import { useNavigate } from "react-router-dom"
import { useAuthCtx } from '../context/auth'

const SignIn = () => {
  const navigate = useNavigate()
  const {_,setTokenCtx} = useAuthCtx()
  useEffect(()=>{
   const token = localStorage.getItem("token")
   if(token){
     navigate("/dashboard")
   }
  },[])
  
  const handleSubmit = async(e)=>{
     e.preventDefault()
     const data = new FormData(e.currentTarget)
     var object = {}
     data.forEach((value,i)=>{
        object[i] = value   
     })
     var json = JSON.stringify(object)

     const res = await signinApi(json)
     if(res){
        setTokenCtx(res.data) // Adding Token in context for state management
        localStorage.setItem("token", res.data)        
        navigate("/dashboard")
     }
  }
  const theme = createTheme()
  return (
    <>
      <ThemeProvider theme={theme}>
        <Container>
           <Box
            sx={{
                marginTop:8,
                display: "flex",
                flexDirection: "column",
                alignItems: "center"
             }}
            >
             <Avatar sx={{m:1, bgcolor: "secondary.main"}}>
                 <LockOutlined></LockOutlined>
             </Avatar>
             <Typography component="h1" variant='h5'>
                Sign-in
             </Typography>
             <Box
               component={"form"}
               noValidate
               onSubmit={handleSubmit}
               sx={{mt:3}}
               >
               <Grid container spacing={2}>
               <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="email"
                      label="Email Address"
                      id="email"
                      autoComplete='email'
                    />
                </Grid>
                <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      name="password"
                      label="Password"
                      type="password"
                      id="password"
                      autoComplete='new-password'
                    />
                </Grid>
               </Grid>
               <Button
                type='submit'
                fullWidth
                variant='contained'
                sx={{mt:3, mb:2}}
               >
                Sign up
               </Button>
             </Box>
            </Box> 
        </Container>
      </ThemeProvider>
    </>
  )
}

export default SignIn
