import { Navigate } from "react-router-dom"
import { useAuthCtx } from "../context/auth"

import React from 'react'

export default function Protected({children}){
  const token = localStorage.getItem("token")
  
  if(!token) {
   return <Navigate to="/signin"/>
  }

  return children
}

