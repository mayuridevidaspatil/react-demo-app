import React, { useEffect } from "react";
import { Nav } from "react-bootstrap"
import { NavLink } from "react-router-dom"
import useAuth from "../hook/useAuth";
import { useAuthCtx } from "../context/auth";
import CountDown from "./CountDown";

function Header({logout}) {
    return (
        <>
            <Nav
                style={{
                    display: "flex",
                    margin: "15px",
                    backgroundColor: "#B0DB43"
                }}
            >
                <NavLink
                    to={"/product"}
                    style={{
                        color: '#54e6f',
                        backgroundColor: '#f0f0f0',
                        padding: "8px",
                        margin: "15px",
                        borderRadius: "10px"
                    }}
                >Product</NavLink>
                <NavLink
                    to={"/customer"}
                    style={{
                        color: '#54e6f',
                        backgroundColor: '#f0f0f0',
                        padding: "8px",
                        margin: "15px",
                        borderRadius: "10px"
                    }}
                >Customer</NavLink>
                <NavLink
                    to={"/service"}
                    style={{
                        color: '#54e6f',
                        backgroundColor: '#f0f0f0',
                        padding: "8px",
                        margin: "15px",
                        borderRadius: "10px"
                    }}
                >Service</NavLink>
                <div style={{
                    right:"100px",
                    position:"absolute",
                    marginTop: "20px"
                }}>
                <NavLink><CountDown/></NavLink>
                <div
                    onClick={logout}
                    style={{
                        color: 'rgb(84, 94, 111)',
                        backgroundColor: 'rgb(240, 240, 240)',
                        padding: "8px",
                        margin: "15px",
                        borderRadius: "10px",
                        position: "fixed",
                        top:"16px",
                        right:"10px"
                    }}
                >Logout</div>
                </div>
            </Nav>
        </>
    )
}

export default Header