import React, { useEffect } from 'react'
import useAuth from '../hook/useAuth'

const Parent = ({children}) => {
   useAuth()
  return (
    <>
       {children}
    </>
  )
}

export default Parent
